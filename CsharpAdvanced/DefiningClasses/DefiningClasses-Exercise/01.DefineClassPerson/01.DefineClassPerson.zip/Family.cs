﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DefiningClasses
{
    public class Family
    {

        public Family()
        {
            this.FamilyList = new List<Person>();
        }

        public List<Person> FamilyList { get; set; }


        public void AddMember(Person member)
        {

            this.FamilyList.Add(member);
        }

        public Person GetOldestMember()
        {
             Person person = this.FamilyList.OrderByDescending(p => p.Age).FirstOrDefault();

             return person;
        }

    }
}
