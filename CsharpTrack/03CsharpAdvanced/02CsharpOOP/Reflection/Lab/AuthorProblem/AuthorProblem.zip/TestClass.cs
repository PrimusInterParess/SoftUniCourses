﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AuthorProblem
{
    [Author("PeshoAtributa")]
   public class TestClass
    {
    }
}
