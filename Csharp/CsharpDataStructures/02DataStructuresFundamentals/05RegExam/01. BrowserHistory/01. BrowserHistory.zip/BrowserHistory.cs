﻿using System.Linq;
using System.Text;

namespace _01._BrowserHistory
{
    using System;
    using System.Collections.Generic;
    using _01._BrowserHistory.Interfaces;

    public class BrowserHistory : IHistory
    {
        // private SinglyLinkedList<ILink> links;

        private Stack<ILink> stack;
        private Queue<ILink> queue;

        private List<ILink> list;

        public BrowserHistory()
        {
            // this.links = new SinglyLinkedList<ILink>();

            this.queue = new Queue<ILink>();
            this.stack = new Stack<ILink>();
            list = new List<ILink>();

        }

        public int Size => this.list.Count;

        public void Clear()
        {

            this.stack.Clear();
            this.queue.Clear();
            list.Clear();


        }

        public bool Contains(ILink link)
        {
            return this.stack.Contains(link);
        }

        public ILink DeleteFirst()
        {
            this.CheckIfEmpty();

            var toReturn = this.queue.Dequeue();

            list.Remove(toReturn);

            foreach (var link in stack)
            {
                if (link.Url == toReturn.Url)
                {
                    stack.Pop();
                    break;

                }
            }

            return toReturn;

        }



        public ILink DeleteLast()
        {
            this.CheckIfEmpty();


            var toReturn = this.stack.Pop();

            list.Remove(toReturn);

            foreach (var link in queue)
            {
                if (link.Url == toReturn.Url)
                {
                    queue.Dequeue();
                    break;

                }
            }

            return toReturn;
        }

        public ILink GetByUrl(string url)
        {
            ILink toReturn = null;

            foreach (var link in queue)
            {
                if (link.Url.ToLower() == url.ToLower())
                {
                    return link;
                }
            }

            return toReturn;
        }

        public ILink LastVisited()
        {
            return this.stack.Peek();
        }

        public void Open(ILink link)
        {
            this.stack.Push(link);
            this.queue.Enqueue(link);
            this.list.Add(link);

        }

        public int RemoveLinks(string url)
        {
            int removedd = 0;

            for (int i = 0; i < list.Count; i++)
            {
                if (this.list[i].Url.ToLower().Contains(url.ToLower()))
                {
                    this.list.RemoveAt(i);
                    removedd++;
                    i--;
                }
            }

            stack = new Stack<ILink>(this.list);

            if (removedd==0)
            {
                throw new InvalidOperationException();
            }

            return removedd;

        }

        public ILink[] ToArray()
        {
            return this.stack.ToArray();
        }

        public List<ILink> ToList()
        {
            return new List<ILink>(stack);
        }

        public string ViewHistory()
        {
            StringBuilder sb = new StringBuilder();

            foreach (var link in stack)
            {
                sb.AppendLine(link.ToString());
            }

            return sb.ToString();
        }

        private void CheckIfEmpty()
        {
            if (this.queue.Count == 0)
            {
                throw new InvalidOperationException();
            }
        }
    }
}
