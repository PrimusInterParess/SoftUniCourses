﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FootBallTeamGenerator
{
   public static class GlobalConstants
   {
       public const string InvalidExeptionMassege = "A name should not be empty.";

       
       
   }
}
