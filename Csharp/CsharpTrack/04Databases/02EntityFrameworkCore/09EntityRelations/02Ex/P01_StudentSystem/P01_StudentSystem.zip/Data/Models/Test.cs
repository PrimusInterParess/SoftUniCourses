﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_StudentSystem.Data.Models
{
    public class Test
    {

        public int Id { get; set; }
        public string test { get; set; }
    }
}
