﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace ProductShop.DataTranferObjects
{
    public class CategoryInputModel
    {
        
        public string Name { get; set; }
    }
}
