﻿namespace CollectionHierarchy.Contracts
{
    public interface IMylist:IAddRemoveCollection
    {
        int Used();
    }
}