﻿using System.Collections.Generic;

namespace CollectionHierarchy.Contracts
{
    public interface IAddCollection
    {
       abstract int Add(string item);
    }
}