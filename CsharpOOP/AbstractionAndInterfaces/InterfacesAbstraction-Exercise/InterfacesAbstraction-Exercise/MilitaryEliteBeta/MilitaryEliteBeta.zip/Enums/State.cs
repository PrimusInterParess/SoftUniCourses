﻿namespace MilitaryElite.Enums
{
    public enum State
    {
        inProgress=1,
        Finished=2
    }
}