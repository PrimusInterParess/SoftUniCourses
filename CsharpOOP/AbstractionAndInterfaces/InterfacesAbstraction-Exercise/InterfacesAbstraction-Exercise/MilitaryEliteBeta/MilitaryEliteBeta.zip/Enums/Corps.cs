﻿namespace MilitaryElite.Enums
{
    public enum Corps
    {
        Airforces=1,
        Marines=2
    }
}